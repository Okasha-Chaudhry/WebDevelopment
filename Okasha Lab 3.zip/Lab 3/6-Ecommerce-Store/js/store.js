/* ShopEase – shared data + helpers (localStorage based demo, no backend) */

const PRODUCTS = [
  { id: 1,  name: "Wireless Headphones", cat: "Electronics", price: 6500,  rating: 4.5, desc: "Bluetooth 5.3 over-ear headphones with 30-hour battery and active noise cancelling." },
  { id: 2,  name: "Smart Watch",         cat: "Electronics", price: 12500, rating: 4.2, desc: "Heart-rate, sleep and step tracking with a bright AMOLED display." },
  { id: 3,  name: "Mechanical Keyboard", cat: "Electronics", price: 8900,  rating: 4.7, desc: "Hot-swappable RGB keyboard with tactile blue switches." },
  { id: 4,  name: "Running Sneakers",    cat: "Fashion",     price: 9800,  rating: 4.4, desc: "Light, breathable running shoes with cushioned soles." },
  { id: 5,  name: "Leather Backpack",    cat: "Fashion",     price: 7200,  rating: 4.6, desc: "Water-resistant 25L backpack with padded laptop compartment." },
  { id: 6,  name: "Sunglasses",          cat: "Fashion",     price: 2400,  rating: 4.0, desc: "UV400 polarised sunglasses with a lightweight frame." },
  { id: 7,  name: "Ceramic Coffee Mug",  cat: "Home",        price: 950,   rating: 4.3, desc: "350ml handmade ceramic mug, microwave and dishwasher safe." },
  { id: 8,  name: "Desk Lamp",           cat: "Home",        price: 3100,  rating: 4.5, desc: "LED desk lamp with 3 colour modes and touch dimming." },
  { id: 9,  name: "Indoor Plant Pot",    cat: "Home",        price: 1350,  rating: 4.1, desc: "Minimal matte pot with drainage tray, ideal for succulents." },
  { id: 10, name: "Clean Code (Book)",   cat: "Books",       price: 3500,  rating: 4.8, desc: "A handbook of agile software craftsmanship by Robert C. Martin." },
  { id: 11, name: "Algorithms (CLRS)",   cat: "Books",       price: 5200,  rating: 4.9, desc: "Introduction to Algorithms – the standard university textbook." },
  { id: 12, name: "Notebook Set",        cat: "Books",       price: 800,   rating: 4.2, desc: "Pack of 3 A5 ruled notebooks with hard covers." }
];

const SHIPPING_FEE = 250;
const FREE_SHIPPING_ABOVE = 10000;

/* ---------- storage ---------- */
const LS = {
  get(k, d) { try { const v = JSON.parse(localStorage.getItem(k)); return v === null ? d : v; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} },
  del(k) { try { localStorage.removeItem(k); } catch (e) {} }
};

/* product image: images/p<id>.jpg (add your own photos); neutral label tile shows until/unless the file exists */
const thumbHtml = (p, extra = "") =>
  '<div class="thumb ' + extra + '"><span class="thumb-label">' + p.cat + '</span>' +
  '<img src="images/p' + p.id + '.jpg" alt="' + escapeHtml(p.name) + '" loading="lazy" onerror="this.remove()"></div>';

const money = n => "Rs " + Number(n).toLocaleString("en-PK");
const findProduct = id => PRODUCTS.find(p => p.id === Number(id));
const escapeHtml = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const stars = r => { const full = Math.round(r); return "★".repeat(full) + "☆".repeat(5 - full); };

/* ---------- auth (demo only: passwords are stored in plain text in localStorage) ---------- */
const Auth = {
  users() { return LS.get("se_users", []); },
  current() { return LS.get("se_session", null); },
  signup(name, email, password) {
    const users = this.users();
    email = email.trim().toLowerCase();
    if (users.some(u => u.email === email)) return { ok: false, error: "An account with this email already exists." };
    users.push({ name: name.trim(), email, password });
    LS.set("se_users", users);
    return { ok: true };
  },
  login(email, password) {
    email = email.trim().toLowerCase();
    const u = this.users().find(u => u.email === email && u.password === password);
    if (!u) return { ok: false, error: "Invalid email or password." };
    LS.set("se_session", { name: u.name, email: u.email });
    return { ok: true, user: u };
  },
  logout() { LS.del("se_session"); }
};

/* ---------- cart ---------- */
const Cart = {
  items() { return LS.get("se_cart", []); },           // [{id, qty}]
  save(items) { LS.set("se_cart", items); updateNav(); },
  add(id, qty = 1) {
    const items = this.items();
    const row = items.find(i => i.id === Number(id));
    if (row) row.qty = Math.min(10, row.qty + qty); else items.push({ id: Number(id), qty });
    this.save(items);
  },
  setQty(id, qty) {
    let items = this.items();
    qty = Math.max(0, Math.min(10, Number(qty) || 0));
    if (qty === 0) items = items.filter(i => i.id !== Number(id));
    else items.forEach(i => { if (i.id === Number(id)) i.qty = qty; });
    this.save(items);
  },
  remove(id) { this.save(this.items().filter(i => i.id !== Number(id))); },
  clear() { this.save([]); },
  count() { return this.items().reduce((n, i) => n + i.qty, 0); },
  subtotal() { return this.items().reduce((s, i) => s + (findProduct(i.id)?.price || 0) * i.qty, 0); },
  shipping() { const s = this.subtotal(); return s === 0 || s >= FREE_SHIPPING_ABOVE ? 0 : SHIPPING_FEE; },
  total() { return this.subtotal() + this.shipping(); }
};

/* ---------- reviews ---------- */
const SEED_REVIEWS = [
  { id: 1, productId: 1,  name: "Ayesha K.", rating: 5, text: "Sound quality is amazing and the battery really lasts all week.", date: "2026-08-12" },
  { id: 2, productId: 10, name: "Hassan A.", rating: 5, text: "Every CS student should own this. Delivery was quick too!",      date: "2026-08-20" },
  { id: 3, productId: 4,  name: "Maryam F.", rating: 4, text: "Very comfortable for daily runs. Colour is slightly brighter than photos.", date: "2026-09-02" },
  { id: 4, productId: 3,  name: "Talha K.",  rating: 5, text: "Typing feel is fantastic. Worth every rupee.",                   date: "2026-09-10" }
];
const Reviews = {
  all() { return LS.get("se_reviews", SEED_REVIEWS); },
  forProduct(pid) { return this.all().filter(r => r.productId === Number(pid)); },
  add(r) {
    const list = this.all();
    list.unshift({ id: Date.now(), date: new Date().toISOString().slice(0, 10), ...r });
    LS.set("se_reviews", list);
  },
  avg(pid, base) {
    const rs = this.forProduct(pid);
    if (!rs.length) return base;
    return (rs.reduce((s, r) => s + r.rating, 0) + base) / (rs.length + 1);
  }
};

/* ---------- navbar: cart badge + login/logout state (navbar markup lives in each page) ---------- */
function updateNav() {
  document.querySelectorAll(".cart-count").forEach(el => {
    const n = Cart.count();
    el.textContent = n;
    el.classList.toggle("d-none", n === 0);
  });
  const user = Auth.current();
  const guest = document.getElementById("navGuest");
  const userBox = document.getElementById("navUser");
  if (guest) guest.classList.toggle("d-none", !!user);
  if (userBox) {
    userBox.classList.toggle("d-none", !user);
    const nm = document.getElementById("navUserName");
    if (nm && user) nm.textContent = user.name.split(" ")[0];
  }
}

function showToast(message, type = "success") {
  let wrap = document.getElementById("toastWrap");
  if (!wrap) {
    wrap = document.createElement("div");
    wrap.id = "toastWrap";
    wrap.className = "toast-container position-fixed bottom-0 end-0 p-3";
    document.body.appendChild(wrap);
  }
  const el = document.createElement("div");
  el.className = "toast align-items-center text-bg-" + type + " border-0";
  el.setAttribute("role", "alert");
  el.innerHTML = '<div class="d-flex"><div class="toast-body">' + escapeHtml(message) + '</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>';
  wrap.appendChild(el);
  const t = new bootstrap.Toast(el, { delay: 2200 });
  el.addEventListener("hidden.bs.toast", () => el.remove());
  t.show();
}

document.addEventListener("DOMContentLoaded", () => {
  updateNav();
  const lo = document.getElementById("logoutBtn");
  if (lo) lo.addEventListener("click", e => { e.preventDefault(); Auth.logout(); updateNav(); showToast("Logged out", "secondary"); if (document.body.dataset.protected) location.href = "login.html"; });
});
