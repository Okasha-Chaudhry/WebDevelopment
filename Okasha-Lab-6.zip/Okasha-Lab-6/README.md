# Full Stack Web Development - Lab 06
Async JavaScript: async/await, fetch and Promise.all (uses the JSONPlaceholder dummy API).

## Run (Node.js 18+ required)
    node task1.js
    node task2.js
