// Task 2: Promise.all on two async operations; resolve/reject based on validity of both results
const API_URL = "https://jsonplaceholder.typicode.com";

// Student details shown in the output (replaces the dummy API's name/username/email)
const MY_DETAILS = {
    name: "Okasha",
    username: "Okasha Chaudhry",
    email: "okashachaudhry123@gmail.com",
};

async function getUser(userId) {
    const res = await fetch(`${API_URL}/users/${userId}`);
    if (!res.ok) throw new Error("Failed to fetch user");
    const data = await res.json();
    return { ...data, ...MY_DETAILS };
}

async function getPost(postId) {
    const res = await fetch(`${API_URL}/posts/${postId}`);
    if (!res.ok) throw new Error("Failed to fetch post");
    return res.json();
}

const isValidUser = (u) => Boolean(u && u.id && u.name && u.email);
const isValidPost = (p) => Boolean(p && p.id && p.title && p.body);

function getUserAndPost(userId, postId) {
    return new Promise((resolve, reject) => {
        Promise.all([getUser(userId), getPost(postId)])
            .then(([user, post]) => {
                if (isValidUser(user) && isValidPost(post)) {
                    resolve({ user, post });   // both valid -> accept main promise
                } else {
                    reject(new Error("User or post details are not valid"));
                }
            })
            .catch(reject);                    // any fetch failed -> reject main promise
    });
}

// Success case
getUserAndPost(1, 1)
    .then((result) => {
        console.log("SUCCESS - both fetched and valid:");
        console.log(result);
    })
    .catch((err) => console.log("ERROR:", err.message));

// Failure case (post 9999 does not exist)
getUserAndPost(1, 9999)
    .then((result) => console.log(result))
    .catch((err) => console.log("ERROR (expected):", err.message));
