// Task 1: async function that returns a valid user on success and an error on failure
const API_URL = "https://jsonplaceholder.typicode.com";

// Student details shown in the output (replaces the dummy API's name/username/email)
const MY_DETAILS = {
    name: "Okasha",
    username: "Okasha Chaudhry",
    email: "okashachaudhry123@gmail.com",
};

async function getUser(userId) {
    const res = await fetch(`${API_URL}/users/${userId}`);

    if (!res.ok) {
        throw new Error(`Could not fetch user (status ${res.status})`);
    }

    const data = await res.json();

    // make sure the object is a valid user
    if (!data.id || !data.name || !data.email) {
        throw new Error("Received an invalid user object");
    }

    return { ...data, ...MY_DETAILS };
}

// Success case
getUser(1)
    .then((user) => {
        console.log("SUCCESS - user fetched:");
        console.log(user);
    })
    .catch((err) => console.log("ERROR:", err.message));

// Failure case (user 9999 does not exist -> 404)
getUser(9999)
    .then((user) => console.log(user))
    .catch((err) => console.log("ERROR (expected):", err.message));
